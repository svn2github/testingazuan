#!/bin/sh
java -cp ./hsqldb1_8_0_2.jar org.hsqldb.Server -database.0 ./foodmart -database.1 ./spagobi -database.2 ./spagobigeo -database.3 ./jbpm -dbname.0 foodmart -dbname.1 spagobi -dbname.2 spagobigeo -dbname.3 jbpm
