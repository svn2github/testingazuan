////////////////////////////////////////////////////////////////////////////////
/// @brief palo element
///
/// @file
///
/// Copyright (C) 2006-2010 Jedox AG
///
/// This program is free software; you can redistribute it and/or modify it
/// under the terms of the GNU General Public License (Version 2) as published
/// by the Free Software Foundation at http://www.gnu.org/copyleft/gpl.html.
///
/// This program is distributed in the hope that it will be useful, but WITHOUT
/// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
/// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
/// more details.
///
/// You should have received a copy of the GNU General Public License along with
/// this program; if not, write to the Free Software Foundation, Inc., 59 Temple
/// Place, Suite 330, Boston, MA 02111-1307 USA
///
/// You may obtain a copy of the License at
///
/// <a href="http://www.jedox.com/license_palo_suite.txt">
///   http://www.jedox.com/license_palo_suite.txt
/// </a>
///
/// If you are developing and distributing open source applications under the
/// GPL License, then you are free to use Palo under the GPL License.  For OEMs,
/// ISVs, and VARs who distribute Palo with their products, and do not license
/// and distribute their source code under the GPL, Jedox provides a flexible
/// OEM Commercial License.
///
/// Portions of the code developed by triagens GmbH, Koeln on behalf of Jedox
/// AG. Intellectual property rights for these portions has triagens GmbH,
/// Koeln, or othervise Jedox AG, Freiburg. Exclusive worldwide exploitation
/// right (commercial copyright) has Jedox AG, Freiburg.
///
/// @author Frank Celler, triagens GmbH, Cologne, Germany
/// @author Achim Brandt, triagens GmbH, Cologne, Germany
/// @author Tobias Lauer, Jedox AG, Freiburg, Germany
/// @author Christoffer Anselm, Jedox AG, Freiburg, Germany
/// @author Zurab Khadikov, Jedox AG, Freiburg, Germany
////////////////////////////////////////////////////////////////////////////////

#include "Olap/Element.h"

#include "Olap/Dimension.h"

namespace palo {
LevelType Element::getLevel(Dimension* dimension)
{
	dimension->checkLevelIndentDepth();
	return level;
}

IndentType Element::getIndent(Dimension* dimension)
{
	dimension->checkLevelIndentDepth();
	return indent;
}

DepthType Element::getDepth(Dimension* dimension)
{
	dimension->checkLevelIndentDepth();
	return depth;
}

void Element::setBaseElements(const map<IdentifierType, double>& baseElements)
{
	this->baseElements = baseElements;
	numBaseElements = baseElements.size();
}

const map<IdentifierType, double>* Element::getBaseElements(Dimension* dimension)
{
	dimension->checkBaseElements();
	return &baseElements;
}

size_t Element::getNumBaseElements(Dimension* dimension)
{
	dimension->checkBaseElements();
	return numBaseElements;
}

#ifdef ENABLE_GPU_SERVER

void Element::setBaseRanges (const BaseRangesType& baseRanges)
{
    this->baseRanges = baseRanges;
}

const BaseRangesType* Element::getBaseRanges (Dimension* dimension)
{
    dimension->updateLevelIndentDepth();
    return &this->baseRanges;
}

void Element::setFilterBaseRanges (const FilterBaseRangesType& filterBaseRanges)
{
    this->filterBaseRanges = filterBaseRanges;
}

const FilterBaseRangesType* Element::getFilterBaseRanges (Dimension* dimension)
{
    dimension->updateLevelIndentDepth();
    return &this->filterBaseRanges;
}

void Element::computeBaseRanges () {
    bool showDebug = false;
    if (showDebug)
        cout << "Element " << this->getIdentifier() << ": " << endl;

    if (this->getElementType() != CONSOLIDATED && this->getElementType() != NUMERIC) {
        if (showDebug)
            cout << "-" << endl;
        return;
    }

    // Create ranges
    baseRanges.clear();

    if (baseElements.empty()) {
        if (showDebug)
            cout << "ERROR: 'baseElements' are not defined!" << endl;
        return;
    }

    // We assume base elements are sorted (looks like this is always the case -- if not, we'll have to SORT first!)
    for (map<IdentifierType, double>::const_iterator c = baseElements.begin(); c != baseElements.end(); c++) {

        if (c == baseElements.begin()) {	// start new range
            if (showDebug)
                cout << "[" << c->first << ":" << endl;
            baseRanges.push_back(BaseRangeType(
                c->first,	// start of range
                c->first,	// temporary end of range
                c->second
                ));
        } else if (c->first == baseRanges.back().range.first + 1 && c->second == baseRanges.back().weight) {  // contiguous, extend range
            baseRanges.back().range.second++;
        } else {							// not contiguous, start new range
            if (showDebug)
                cout << baseRanges.back().range.second << " (" << baseRanges.back().weight << ")] [" << c->first << ":" << endl;
            baseRanges.push_back(BaseRangeType(
                c->first,	// start of range
                c->first,	// temporary end of range
                c->second
                ));
        }

    }
    if (showDebug)
        cout << baseRanges.back().range.second << " (" << baseRanges.back().weight << ")]" << endl;
}

#endif

}
