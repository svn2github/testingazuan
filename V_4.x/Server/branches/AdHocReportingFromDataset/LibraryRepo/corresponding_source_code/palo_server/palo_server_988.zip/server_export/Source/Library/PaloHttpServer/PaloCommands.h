/* C++ code produced by gperf version 3.0.1 */
/* Command-line: gperf -CGD -N PaloValue -K option -L C++ -t Library/PaloHttpServer/PaloCommands.gperf  */
/* Computed positions: -k'1,8,$' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gnu-gperf@gnu.org>."
#endif

#line 1 "Library/PaloHttpServer/PaloCommands.gperf"

#include "palo.h"

#include "PaloHttpServer/PaloRequestHandler.h"
#line 6 "Library/PaloHttpServer/PaloCommands.gperf"
struct CommandOption {
	const char * option;
	int code;
};

#define TOTAL_KEYWORDS 70
#define MIN_WORD_LENGTH 3
#define MAX_WORD_LENGTH 19
#define MIN_HASH_VALUE 5
#define MAX_HASH_VALUE 169
/* maximum key range = 165, duplicates = 0 */

class Perfect_Hash {
private:
	static inline unsigned int hash(const char *str, unsigned int len);
public:
	static const struct CommandOption *PaloValue(const char *str, unsigned int len);
};

inline unsigned int Perfect_Hash::hash(register const char *str, register unsigned int len)
{
	static const unsigned char asso_values[] = {170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 0, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 70, 60, 70, 170, 170, 170, 170, 170, 170, 170, 170, 0, 170, 170, 170, 170, 170, 0, 170, 170, 0, 170, 0, 170, 170, 170, 170,
	        170, 170, 170, 170, 30, 95, 10, 40, 15, 105, 170, 95, 45, 170, 0, 55, 85, 0, 20, 45, 170, 0, 0, 5, 70, 0, 0, 170, 0, 5, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
	        170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170, 170};
	register int hval = len;

	switch (hval) {
	default:
		hval += asso_values[(unsigned char)str[7]];
		/*FALLTHROUGH*/
	case 7:
	case 6:
	case 5:
	case 4:
	case 3:
	case 2:
	case 1:
		hval += asso_values[(unsigned char)str[0]];
		break;
	}
	return hval + asso_values[(unsigned char)str[len - 1]];
}

static const struct CommandOption wordlist[] = {
#line 54 "Library/PaloHttpServer/PaloCommands.gperf"
        {"steps", palo::PaloRequestHandler::CMD_NUM_STEPS},
#line 72 "Library/PaloHttpServer/PaloCommands.gperf"
        {"values", palo::PaloRequestHandler::CMD_VALUES},
#line 73 "Library/PaloHttpServer/PaloCommands.gperf"
        {"weights", palo::PaloRequestHandler::CMD_WEIGHTS},
#line 75 "Library/PaloHttpServer/PaloCommands.gperf"
        {"X-PALO-SV", palo::PaloRequestHandler::CMD_X_PALO_SERVER},
#line 40 "Library/PaloHttpServer/PaloCommands.gperf"
        {"types", palo::PaloRequestHandler::CMD_ID_TYPES},
#line 50 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_paths", palo::PaloRequestHandler::CMD_NAME_PATHS},
#line 26 "Library/PaloHttpServer/PaloCommands.gperf"
        {"children", palo::PaloRequestHandler::CMD_ID_CHILDREN},
#line 38 "Library/PaloHttpServer/PaloCommands.gperf"
        {"rule", palo::PaloRequestHandler::CMD_ID_RULE},
#line 71 "Library/PaloHttpServer/PaloCommands.gperf"
        {"value", palo::PaloRequestHandler::CMD_VALUE},
#line 67 "Library/PaloHttpServer/PaloCommands.gperf"
        {"source", palo::PaloRequestHandler::CMD_SOURCE},
#line 16 "Library/PaloHttpServer/PaloCommands.gperf"
        {"comment", palo::PaloRequestHandler::CMD_COMMENT},
#line 32 "Library/PaloHttpServer/PaloCommands.gperf"
        {"elements", palo::PaloRequestHandler::CMD_ID_ELEMENTS},
#line 39 "Library/PaloHttpServer/PaloCommands.gperf"
        {"type", palo::PaloRequestHandler::CMD_ID_TYPE},
#line 22 "Library/PaloHttpServer/PaloCommands.gperf"
        {"event", palo::PaloRequestHandler::CMD_EVENT},
#line 31 "Library/PaloHttpServer/PaloCommands.gperf"
        {"element", palo::PaloRequestHandler::CMD_ID_ELEMENT},
#line 48 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_elements", palo::PaloRequestHandler::CMD_NAME_ELEMENTS},
#line 27 "Library/PaloHttpServer/PaloCommands.gperf"
        {"cube", palo::PaloRequestHandler::CMD_ID_CUBE},
#line 23 "Library/PaloHttpServer/PaloCommands.gperf"
        {"event_processor", palo::PaloRequestHandler::CMD_EVENT_PROCESSOR},
#line 47 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_element", palo::PaloRequestHandler::CMD_NAME_ELEMENT},
#line 44 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_database", palo::PaloRequestHandler::CMD_NAME_DATABASE},
#line 58 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_attribute", palo::PaloRequestHandler::CMD_SHOW_ATTRIBUTE},
#line 12 "Library/PaloHttpServer/PaloCommands.gperf"
        {"action", palo::PaloRequestHandler::CMD_ACTION, },
#line 51 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_path_to", palo::PaloRequestHandler::CMD_NAME_PATH_TO},
#line 53 "Library/PaloHttpServer/PaloCommands.gperf"
        {"new_name", palo::PaloRequestHandler::CMD_NEW_NAME},
#line 18 "Library/PaloHttpServer/PaloCommands.gperf"
        {"condition", palo::PaloRequestHandler::CMD_CONDITION},
#line 57 "Library/PaloHttpServer/PaloCommands.gperf"
        {"sid", palo::PaloRequestHandler::CMD_SID},
#line 74 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_lock_info", palo::PaloRequestHandler::CMD_SHOW_LOCK_INFO},
#line 17 "Library/PaloHttpServer/PaloCommands.gperf"
        {"complete", palo::PaloRequestHandler::CMD_COMPLETE},
#line 64 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_user_info", palo::PaloRequestHandler::CMD_SHOW_USER_INFO},
#line 36 "Library/PaloHttpServer/PaloCommands.gperf"
        {"paths", palo::PaloRequestHandler::CMD_ID_PATHS},
#line 56 "Library/PaloHttpServer/PaloCommands.gperf"
        {"position", palo::PaloRequestHandler::CMD_POSITION},
#line 41 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_area", palo::PaloRequestHandler::CMD_NAME_AREA},
#line 66 "Library/PaloHttpServer/PaloCommands.gperf"
        {"skip_empty", palo::PaloRequestHandler::CMD_SKIP_EMPTY},
#line 42 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_children", palo::PaloRequestHandler::CMD_NAME_CHILDREN},
#line 33 "Library/PaloHttpServer/PaloCommands.gperf"
        {"lock", palo::PaloRequestHandler::CMD_ID_LOCK},
#line 25 "Library/PaloHttpServer/PaloCommands.gperf"
        {"area", palo::PaloRequestHandler::CMD_ID_AREA},
#line 62 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_rules", palo::PaloRequestHandler::CMD_SHOW_RULES},
#line 60 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_normal", palo::PaloRequestHandler::CMD_SHOW_NORMAL},
#line 11 "Library/PaloHttpServer/PaloCommands.gperf"
        {"activate", palo::PaloRequestHandler::CMD_ACTIVATE},
#line 29 "Library/PaloHttpServer/PaloCommands.gperf"
        {"dimension", palo::PaloRequestHandler::CMD_ID_DIMENSION},
#line 30 "Library/PaloHttpServer/PaloCommands.gperf"
        {"dimensions", palo::PaloRequestHandler::CMD_ID_DIMENSIONS},
#line 37 "Library/PaloHttpServer/PaloCommands.gperf"
        {"path_to", palo::PaloRequestHandler::CMD_ID_PATH_TO},
#line 13 "Library/PaloHttpServer/PaloCommands.gperf"
        {"add", palo::PaloRequestHandler::CMD_ADD},
#line 52 "Library/PaloHttpServer/PaloCommands.gperf"
        {"user", palo::PaloRequestHandler::CMD_NAME_USER},
#line 28 "Library/PaloHttpServer/PaloCommands.gperf"
        {"database", palo::PaloRequestHandler::CMD_ID_DATABASE},
#line 61 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_rule", palo::PaloRequestHandler::CMD_SHOW_RULE},
#line 77 "Library/PaloHttpServer/PaloCommands.gperf"
        {"X-PALO-DIM", palo::PaloRequestHandler::CMD_X_PALO_DIMENSION},
#line 69 "Library/PaloHttpServer/PaloCommands.gperf"
        {"use_identifier", palo::PaloRequestHandler::CMD_USE_IDENTIFIER},
#line 21 "Library/PaloHttpServer/PaloCommands.gperf"
        {"external_identifier", palo::PaloRequestHandler::CMD_EXTERNAL_IDENTIFIER},
#line 70 "Library/PaloHttpServer/PaloCommands.gperf"
        {"use_rules", palo::PaloRequestHandler::CMD_USE_RULES},
#line 19 "Library/PaloHttpServer/PaloCommands.gperf"
        {"definition", palo::PaloRequestHandler::CMD_DEFINITION},
#line 63 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_system", palo::PaloRequestHandler::CMD_SHOW_SYSTEM},
#line 59 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_gputype", palo::PaloRequestHandler::CMD_SHOW_GPUTYPE},
#line 45 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_dimension", palo::PaloRequestHandler::CMD_NAME_DIMENSION},
#line 46 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_dimensions", palo::PaloRequestHandler::CMD_NAME_DIMENSIONS},
#line 68 "Library/PaloHttpServer/PaloCommands.gperf"
        {"splash", palo::PaloRequestHandler::CMD_SPLASH},
#line 34 "Library/PaloHttpServer/PaloCommands.gperf"
        {"mode", palo::PaloRequestHandler::CMD_ID_MODE},
#line 49 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_path", palo::PaloRequestHandler::CMD_NAME_PATH},
#line 24 "Library/PaloHttpServer/PaloCommands.gperf"
        {"functions", palo::PaloRequestHandler::CMD_FUNCTIONS},
#line 20 "Library/PaloHttpServer/PaloCommands.gperf"
        {"extern_password", palo::PaloRequestHandler::CMD_EXTERN_PASSWORD},
#line 43 "Library/PaloHttpServer/PaloCommands.gperf"
        {"name_cube", palo::PaloRequestHandler::CMD_NAME_CUBE},
#line 15 "Library/PaloHttpServer/PaloCommands.gperf"
        {"blocksize", palo::PaloRequestHandler::CMD_BLOCKSIZE},
#line 79 "Library/PaloHttpServer/PaloCommands.gperf"
        {"X-PALO-CC", palo::PaloRequestHandler::CMD_X_PALO_CUBE_CLIENT_CACHE},
#line 55 "Library/PaloHttpServer/PaloCommands.gperf"
        {"password", palo::PaloRequestHandler::CMD_PASSWORD},
#line 65 "Library/PaloHttpServer/PaloCommands.gperf"
        {"show_info", palo::PaloRequestHandler::CMD_SHOW_INFO},
#line 78 "Library/PaloHttpServer/PaloCommands.gperf"
        {"X-PALO-CB", palo::PaloRequestHandler::CMD_X_PALO_CUBE},
#line 35 "Library/PaloHttpServer/PaloCommands.gperf"
        {"path", palo::PaloRequestHandler::CMD_ID_PATH},
#line 76 "Library/PaloHttpServer/PaloCommands.gperf"
        {"X-PALO-DB", palo::PaloRequestHandler::CMD_X_PALO_DATABASE},
#line 14 "Library/PaloHttpServer/PaloCommands.gperf"
        {"base_only", palo::PaloRequestHandler::CMD_BASE_ONLY},
#line 80 "Library/PaloHttpServer/PaloCommands.gperf"
        {"Content-Length", palo::PaloRequestHandler::CMD_CONTENT_LENGTH}};

static const signed char lookup[] = {-1, -1, -1, -1, -1, 0, 1, 2, -1, 3, 4, -1, -1, -1, -1, 5, -1, -1, 6, 7, 8, 9, 10, 11, 12, 13, -1, 14, 15, 16, 17, -1, 18, 19, 20, -1, 21, 22, 23, 24, -1, -1, -1, 25, 26, -1, -1, -1, 27, 28, 29, -1, -1, 30, 31, 32, -1, -1, 33, 34, -1, -1, -1, -1, 35, 36, 37, -1, 38, 39, 40, -1, 41, 42, 43, -1, -1, -1, 44, 45, 46, -1, -1, -1, 47, -1, -1, -1, -1, 48, -1, -1, -1, -1, 49, 50, 51, 52, -1, 53, 54, 55, -1, -1, 56, -1, -1, -1, -1, 57, -1, -1, -1, -1, 58, 59, -1, -1,
        -1, 60, -1, -1, -1, -1, 61, -1, -1, -1, -1, 62, -1, -1, -1, 63, 64, -1, -1, -1, -1, 65, -1, -1, -1, -1, 66, -1, -1, -1, -1, 67, -1, -1, -1, -1, -1, -1, -1, -1, -1, 68, -1, -1, -1, -1, -1, -1, -1, -1, -1, 69};

const struct CommandOption *
Perfect_Hash::PaloValue(register const char *str, register unsigned int len)
{
	if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH) {
		register int key = hash(str, len);

		if (key <= MAX_HASH_VALUE && key >= 0) {
			register int index = lookup[key];

			if (index >= 0) {
				register const char *s = wordlist[index].option;

				if (*str == *s && !strcmp(str + 1, s + 1))
					return &wordlist[index];
			}
		}
	}
	return 0;
}
